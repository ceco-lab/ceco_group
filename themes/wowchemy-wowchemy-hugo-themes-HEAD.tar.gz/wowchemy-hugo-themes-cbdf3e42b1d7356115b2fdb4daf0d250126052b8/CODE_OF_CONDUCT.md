# Code of Conduct

We want to foster a positive, inclusive, and welcoming environment 💜

We expect you to follow our [Code of Conduct](https://wowchemy.com/docs/hugo-tutorials/contribute/) to fulfil this goal.
